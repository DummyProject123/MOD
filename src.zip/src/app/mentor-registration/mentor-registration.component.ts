import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-registration',
  templateUrl: './mentor-registration.component.html',
  styleUrls: ['./mentor-registration.component.css']
})
export class MentorRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
