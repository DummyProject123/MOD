import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RegistrationComponentComponent } from './registration-component/registration-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { AdminComponentComponent } from './admin-component/admin-component.component';
import { MyMaterialModule } from './material.module';
import { RouterModule, Routes } from '@angular/router';

import { HttpClientModule } from '@angular/common/http';


import { MatButtonModule, MatCardModule, MatMenuModule, MatToolbarModule, MatIconModule, MatSidenavModule, MatListModule } from '@angular/material';

import { AppComponent } from './app.component';

import { MentorLoginComponent } from './mentor-login-component/mentor-login.component';
import { MentorRegistrationComponent } from './mentor-registration/mentor-registration.component';

import { UserProfileComponent } from './user-profile/user-profile.component';





@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponentComponent,
    LoginComponentComponent,
    AdminComponentComponent,

    MentorLoginComponent,

    MentorRegistrationComponent,

    

    UserProfileComponent,

    

    
   
  ],
 


  imports: [
    HttpModule,
    HttpClientModule,
    MatButtonModule,
    MatMenuModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    BrowserModule,
    AppRoutingModule,
    MyMaterialModule,
    BrowserAnimationsModule,

    RouterModule.forRoot([
      { path: '', redirectTo: '/', pathMatch: 'full' },
      { path: 'register', component: RegistrationComponentComponent },
      { path: 'login', component: LoginComponentComponent },
      { path: 'admin', component: AdminComponentComponent },
      { path: 'mentor', component: MentorLoginComponent },
      { path: 'mentorregister', component: MentorRegistrationComponent },
    
          ]),
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }

